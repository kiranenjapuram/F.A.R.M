#! /usr/bin/bash

rosrun beg1 distance_sub.py #check stepper_sub.py..there are some changes!
exit 0
